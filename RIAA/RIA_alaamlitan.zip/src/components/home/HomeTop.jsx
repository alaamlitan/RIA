import React, { Component, Fragment } from 'react'
import {Container, Row, Col} from 'react-bootstrap';
import HomeSlider from './HomeSlider';


export class HomeTop extends Component {
  render() {
    return (
      <Fragment>
        <Container className='p-0 pt-2' >
            <Row><center>
                <Col lg={10} md={10} sm={12} xs={12}><HomeSlider /></Col><div style={{ width: "200px", height: "auto", marginRight: "20px" }}>
                  
                
                </div>
           </center> </Row>
        </Container>
      </Fragment>
    )
  }
}

export default HomeTop

import React, { Component } from 'react';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import {Container, Row, Col, Button} from 'react-bootstrap';
import { Link } from 'react-router-dom';

export class HomeSlider extends Component {
  render() {
    const settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      autoplayspeed: 1500
      
    };
    return (<div > 
    
        <Slider {...settings}>
          <div>
            <h3 style={{textAlign:'center'}}> 
              <img alt="First slider" width={900} height={360} src={require('../../assets/images/im1.jpg')} />Welcome to the online store for making cakes ...
            </h3>
          </div>
          <div >
            <h3 style={{textAlign:'center'}}> 
              <img alt="First slider" width={900} height={360} src={require('../../assets/images/im2.jpg')} />Made with love for you</h3>
            
          </div>
          <div>
            <h3 style={{textAlign:'center'}}>
              <img alt="First slider" width={900} height={360} src={require('../../assets/images/im3.jpg')} /> Alaa Cake Shop welcomes you
            </h3>
          </div>
          <div>
            <h3 style={{textAlign:'center'}}>
              <img alt="First slider" width={900} height={360} src={require('../../assets/images/im4.jpg')} />Made with the finest materials
            </h3>
          </div>
        <div >
            <h3>
              <img alt="First slider" width={950} height={360} src={require('../../assets/images/im5.jpg')} /> 
            </h3>
          </div>
        </Slider> <br /><br />
  

      </div>
      
    );
  }
}

export default HomeSlider

import React, { Component, Fragment } from 'react';
import Col from 'react-bootstrap/Col'; 
import Container from 'react-bootstrap/Container'; 
import Image from 'react-bootstrap/Image'; 
import Row from 'react-bootstrap/Row'; 

export class Cake extends Component {
  render() {
    return (
      <div>
        <Fragment>
                <Container> 
                    <br />
                    <Row> 
                     
        <Col xs={4} md={3}> 
          <Image width={200} height={200} src={require('../../assets/images/a1.JPG')} roundedCircle /> 
        </Col> 
        
        <Col xs={4} md={3}> 
          <Image width={200} height={200} src={require('../../assets/images/a2.JPG')} roundedCircle /> 
        </Col> 
        <Col xs={4} md={3}> 
          <Image width={200} height={200} src={require('../../assets/images/a3.JPG')} roundedCircle /> 
        </Col> 
        <Col xs={4} md={3}> 
          <Image width={200} height={200} src={require('../../assets/images/a4.jpg')} roundedCircle /> 
        </Col> 
      </Row> 
    </Container> 
        </Fragment>
      </div>
    )
  }
}

export default Cake

import React, { Component, Fragment } from 'react';
import { Container, Row } from 'react-bootstrap';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import Card from 'react-bootstrap/Card';
export class View extends Component {

    constructor() {
        super();
        this.next = this.next.bind(this);
        this.previous = this.previous.bind(this)
    }
    next() {
        this.slider.slickNext();
    }
    previous() {
        this.slider.slickPrev();
    }
    render() {
        const settings = {
            dots: false,
            infinite: true,
            speed: 500,
            slidesToShow: 4,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 1500,
        };
        return (
            <div>
                <Fragment>
                    <Container className="text-center mt-5" fluid>
                        <div className='section-title text-center mb-55'>
                            <a className="btn btn-sm ml-2 site-btn" onClick={this.previous}><i className='fa fa-angle-left'></i></a>
                            <a className="btn btn-sm ml-2 site-btn" onClick={this.next}><i className='fa fa-angle-right'></i></a>
                            <h2>My own store</h2>
                            <p>Some customer photos of the fillings, which are of the highest quality</p>
                        </div>
                        <Row>
                            <Slider ref={c => (this.slider = c)} {...settings}>
                                <div>
                                    
                                        <>
                                            <br />
                                            <Card>
                                                <Card.Body>
                                                    <Card.Text>
                                                    Classic filling with the addition of Italian pistachio filling ..
                                                    </Card.Text>
                                                </Card.Body>
                                                <Card.Img variant="bottom" src={require('../../assets/images/am.jpg')} />
                                            </Card>
                                        </>
                                    
                                </div>
                                <div>
                                   
                                        <>
                                            <br />
                                            <Card>
                                                <Card.Body>
                                                    <Card.Text>
                                                    Luxurious Italian fillings
                                                    </Card.Text>
                                                </Card.Body>
                                                <Card.Img variant="bottom" src={require('../../assets/images/am1.jpg')} />
                                            </Card>
                                        </>
                                    
                                </div>
                                <div>
                                   
                                        <>
                                            <br />
                                            <Card>
                                                <Card.Body>
                                                    <Card.Text>
                                                    Nutella filling with nuts and caramel
                                                    </Card.Text>
                                                </Card.Body>
                                                <Card.Img variant="bottom" src={require('../../assets/images/am2.jpg')} />
                                            </Card>
                                        </>
                                   
                                </div>
                                <div>

                                    <>
                                        <br />
                                        <Card>
                                            <Card.Body>
                                                <Card.Text>
                                                Pistachio filling with cherries and lemon
                                                </Card.Text>
                                            </Card.Body>
                                            <Card.Img variant="bottom" src={require('../../assets/images/am3.jpg')} />
                                        </Card>
                                    </>

                                </div>

                            </Slider>
                        </Row>
                    </Container>
                  
                </Fragment>
            </div>
        )
    }
}

export default View


import React, { Component, Fragment } from 'react';
import { Link } from 'react-router-dom';
import {Container, Row, Col, Card} from 'react-bootstrap';

export class List_Of_Items extends Component {
  render() {
    return (
        <Fragment>
            <Container className="text-center mt-5" fluid>
                <div className='section-title text-center mb-55'>
                    <h2>List Of Items</h2>
                    <p>choose your orders . here is the best!</p>
                </div>
                <Row>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/l1.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Lunch cake with classic filling</p>
                                    <p>Price: 50 DL</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/l2.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Lunch cake sticker and writing in Arabic </p>
                                    <p>Price: 60 DL</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/l4.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Lunch cake with classic filling</p>
                                    <p>Price:45 DL</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/l3.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Lunch cake frosting</p>
                                    <p>Price:55 DL</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/ca1.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Cake with classic filling and chocolate glaze </p>
                                    <p>Price: 280 DL</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/ca2.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Cake with brush filling and rose decoration + acrylic</p>
                                    <p>Price: 200 DL </p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/ca3.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Large cake with classic filling and sugar paste decoration</p>
                                    <p>Price: 380 DL</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/ca4.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Classic filling cake for graduation</p>
                                    <p>Price: 195 DL</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/sw1.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Sweet with crunchy Nutella and caramel, pink and rose color</p>
                                    <p>Price: 7 DL</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/sw2.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Sweet with crunchy Nutella and pistachios</p>
                                    <p>Price: 8 DL</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/sw3.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Sweet with crunchy Nutella, caramel, orange color and rose</p>
                                    <p>Price: 6 DL</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                    <Col className='p-0' lg={3} md={3} sm={6}>
                        <div>
                            <Link to="">
                                <Card>
                                    <Card.Body>
                                        <img alt="Category item" src={require('../../assets/images/sw4.jpg')} className='h-100 w-100 text-center'/>
                                    </Card.Body>
                                    <p>Sweet with crunchy Nutella and pistachios, pink color and heart shape</p>
                                    <p>Price: 9 DL</p>
                                </Card>
                            </Link>
                        </div>
                    </Col>
                </Row>
            </Container>   
      </Fragment>
    )
}
}

export default List_Of_Items


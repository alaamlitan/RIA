import React, { Component, Fragment } from 'react';
import {Container, Breadcrumb, Row, Col} from 'react-bootstrap';
import 'react-inner-image-zoom/lib/InnerImageZoom/styles.css';
import InnerImageZoom from 'react-inner-image-zoom';

import main_img from '../../assets/images/products/product_1/aam1.jpg'
import one_img from '../../assets/images/products/product_1/aam2.jpg'
import two_img from '../../assets/images/products/product_1/aam3.jpg'
import three_img from '../../assets/images/products/product_1/aam4.jpg'
import four_img from '../../assets/images/products/product_1/aam5.JPG'

import ReviewList from './ReviewList';

export class Order extends Component {
    constructor(){
        super();
        this.state={
             previewImg: "0"
        }
   }

   imgOnClick = (event) => {
        let imgSrc = event.target.getAttribute('src');
        this.setState({ previewImg: imgSrc })
   }
    render() {
        if (this.state.previewImg == "0") {
            this.setState({ previewImg: main_img })
        }
        return (
            <Fragment>
            <Container fluid={true}>

                <Row className="p-2">
                <Col className="shadow-sm bg-white pb-3 mt-4" md={12} lg={12} sm={12} xs={12}>
                    <Row>
                        <Col className="p-3 " md={6} lg={6} sm={12} xs={12}>
                                <Row className="p-2">
                                    <Col md={2} lg={2} sm={12} xs={12} >
                                        <Col className="p-0 m-0" >
                                            <img onClick={this.imgOnClick} src={one_img} height={100} width={80} />
                                        </Col>
                                        <Col className="p-0 m-0" md={12} lg={12} sm={3} xs={3}>
                                            <img onClick={this.imgOnClick} src={two_img} height={100} width={80} />
                                        </Col>
                                        <Col className="p-0 m-0" md={12} lg={12} sm={3} xs={3}>
                                            <img onClick={this.imgOnClick} src={three_img} height={100} width={80} />
                                        </Col>
                                        <Col className="p-0 m-0" md={12} lg={12} sm={3} xs={3}>
                                            <img onClick={this.imgOnClick} src={four_img} height={100} width={80} />
                                        </Col>
                                    </Col>
                                    <Col md={10} lg={10} sm={12} xs={12} >
                                        <InnerImageZoom zoomScale={1.5} zoomType={"hover"} src={this.state.previewImg}  />
                                    </Col>
                                </Row>
                        </Col>
                        <Col className="p-3 " md={6} lg={6} sm={12} xs={12}>
                              

                                <div ><br /><br /> <br />
                                      <h4 className="Product-Name">BOOKING </h4>
                              

                                 
                                </div>
                                
                                <div >
                              
                                <div >
                                    
                                    <h6 className="mt-2"> Type Of Product    </h6>
                                    <select className="form-control form-select">
        
                                    <option>CAKE </option>
                                    <option>LUNCH CAKE</option>
                                    <option>SWEET</option> 
                                 
                                    </select>
                                </div>  <div >
                                    <h6 className="mt-2"> CAKE SIZE   </h6>
                                    <select className="form-control form-select">
        
                                    <option>8 People</option>
                                    <option>12 People</option>
                                    <option>15 People</option> 
                                    <option>20 and more </option>
                                    </select>
                                </div>
                                <div >

                                    <h6 className="mt-2"> Filling Type  </h6>
                                    <select className="form-control form-select">
        
                                    <option >classic </option>
                                    <option>Brushes</option>
                                    <option >Nutella Crispy </option>
                                    <option>Pistachio</option>
                                    <option>Others communicate via email</option>




                                    </select>
                                </div>

                                </div>
                             For more information, instagram me  <br />
                                <div className="input-group mt-3">
                                   
                                    <button className="btn btn-dark m-1"> <i className="fa fa-car"></i> OrderNow </button>
                                    <button className="btn btn-secondary m-1"> <i className="fa fa-heart"></i> addToFav </button>
                                    <button className="btn btn-secondary m-1"><a href="https://www.instagram.com/cake_alaa?igsh=MXJqcTZkazRnNnJwNA=="><i className='fab mt-4 m-2 h4 fa-instagram' style={{color:"#ffffff",}}></i></a></button>
  
                             </div>   <Row>
                        
                        <Col className="" md={6} lg={6} sm={12} xs={12}>
                            <ReviewList />
                        </Col>
                    </Row>  
                        </Col>
                    </Row>

                  
                </Col>
            </Row>



            </Container>
    </Fragment>
        )
    }
}

export default Order

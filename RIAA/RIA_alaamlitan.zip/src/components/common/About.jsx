import React, { Component, Fragment } from 'react';
//import {Container, Row, Col, Form, Button} from 'react-bootstrap';
//import { Link } from 'react-router-dom';
import Card from 'react-bootstrap/Card'; 
import Button from 'react-bootstrap/Button';
import Spinner from 'react-bootstrap/Spinner';





export class About extends Component {
  render() {
  return (
  <Fragment>
    <Card>
      <Card.Header>About us</Card.Header>
      <Card.Body>
        <div style={{ display: "flex" }}>
          <Card.Img
            variant="top"
            src={require("../../assets/images/alaa.JPG")}
            style={{ width: "200px", height: "auto", marginRight: "20px" }}
          />
         
          <div>    <br /> <br /> <br /><br />       <br />  <Card.Title>  Hello, I am Chef Alaa Mlitan . </Card.Title>

            <blockquote className="blockquote mb-0">
              <p>
              owner of the electronic store known in the city of Misrata, Libya, for making cakes with the finest Spanish materials and fillings. I make cakes with love for you.
               I hope you like my store   </p>
            </blockquote>
          
          </div>
        </div>
      </Card.Body>
    </Card>
<br /><br />
    <div style={{ float: 'right' }}> <>
  
      <Button variant="dark" disabled>
        <Spinner
          as="span"
          animation="border"
          size="sm"
          role="status"
          aria-hidden="true"
        />
        <span className="visually-hidden">Loading...</span>
      </Button>{' '}
      <Button variant="dark" disabled>
        <Spinner
          as="span"
          animation="grow"
          size="sm"
          role="status"
          aria-hidden="true"
        />
        Loading...
      </Button>
    </></div> 
  </Fragment>
);
  }
}

export default About

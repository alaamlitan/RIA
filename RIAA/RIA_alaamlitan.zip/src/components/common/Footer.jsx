import React, { Component, Fragment } from 'react';
import {Container, Row, Col, Button} from 'react-bootstrap';
import { Link } from 'react-router-dom';
export class Footer extends Component {
  render() {
    return (
      <Fragment>
        <div className="bg-dark text-white" >
        
            <Container >
                <Row>
                
                    
                    <Col className='p-2' lg={5} md={10} sm={7}>
                        <h5>About Resturent</h5>
                        <p><Link to="/menu"><Button variant="light">List Of Items</Button></Link>
                        <Link to="/about_us"><Button variant="light">About us</Button></Link>
                       <Link to="/contact_us"><Button variant="light">Contact us</Button></Link></p>
                    </Col>
                    <Col className='p-3' lg={3} md={3} sm={6}>
                        <h5>Cake online store </h5>
                        <p>Qasr-Ahmed - Misrata, Libya</p>
                        <span><i className='fa fa-envelope'></i> cakealaa@gmail.com</span>
                        

                    </Col> 
                    <Col className='p-2' lg={3} md={3} sm={6}>
                            <h5>Contact us</h5>
                            <a href="https://www.instagram.com/cake_alaa?igsh=MXJqcTZkazRnNnJwNA=="><i className='fab mt-4 m-2 h4 fa-instagram' style={{color:"#ffffff",}}></i></a>
                        <a href="https://www.facebook.com/cake.alaa?mibextid=PlNXYD"><i className='fab mt-4 m-2 h4 fa-facebook' style={{color:"#ffffff",}}></i></a>
                        <a href="https://x.com/_alaamlitan?s=21&t=UmHF0tcz3K__c9OGQTTwCw"><i className='fab mt-4 m-2 h4 fa-twitter' style={{color:"#ffffff",}}></i></a>
                    </Col>
                    
                </Row>
            </Container>
            <Container fluid className='text-center m-0 pt-3 pb-1 bg-light text-black'>
         
            </Container>
        </div>
      </Fragment>
    )
  }
}

export default Footer

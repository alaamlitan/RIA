import React, { Component, Fragment } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import Button from 'react-bootstrap/Button'; 
import Form from 'react-bootstrap/Form';

export class Contact extends Component {
  render() {
    return (
      <Fragment>
        <Container>
            <Row>
              
                <Col className="shadow-sm bg-white mt-2" lg={12} md={12} sm={12} xs={12}>
                    <Row className='text-center'>
                     
                        <Col className="d-flex justify-content-center mt-5" lg={6} md={6} sm={6} xs={6}>
                        <Form><br /> <br /> <h3>Log in to the site</h3> <br />
      <Form.Group className="mb-3" controlId="formBasicEmail"> 
        <Form.Label> We'll never share your email with anyone else</Form.Label> 
        <Form.Control type="email" placeholder="Enter email" /> 
        <Form.Text className="text-muted"> 
          
        </Form.Text> 
      </Form.Group> 
 
      <Form.Group className="mb-3" controlId="formBasicPassword"> 
        <Form.Control type="password" placeholder="Password" />
      </Form.Group> 
      <Button variant="dark" type="submit"> 
        sign in
      </Button> 
     
    </Form> 
                        </Col>
                      <Col className="p-0 m-0" lg={6} md={6} sm={6} xs={6}>
                          
                      <iframe title='FIT Location' src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3369.69574899471!2d15.1866188848282!3d32.373706481095724!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x13a14f004043edbb%3A0x1a0e79278a8fdc3d!2z2YPZitmDINin2YTYp9ih!5e0!3m2!1sar!2sly!4v1708827701968!5m2!1sar!2sly" width="600" height="400" styles="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                          <h6>You can find out about our online store located in Qasr-Ahmed</h6>
                         <br /><br /> </Col> </Row>        
                </Col>
            </Row>
        </Container>
      </Fragment>
    )
  }
}

export default Contact

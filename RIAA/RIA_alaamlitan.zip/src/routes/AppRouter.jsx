import React, { Component, Fragment } from 'react';
import TopNavbar from '../components/TopNavbar';
import Footer from '../components/common/Footer';
import AboutPage from '../pages/AboutPage';
import HomePage from '../pages/HomePage';
import SearchPage from '../pages/SearchPage';
import RegistrationPage from '../pages/RegistrationPage';
import ContactPage from '../pages/ContactPage';
import Order from '../components/products/Order';
import OrderPage from '../pages/OrderPage';

import { BrowserRouter as Router, Route, Routes} from "react-router-dom";
import About from '../components/common/About';

export class AppRouter extends Component {
  render() {
    return (
      <Fragment>
        <TopNavbar />
        <Routes>

        <Route exact path="/order_now" Component={Order} render={(props) => <RegistrationPage {...props} key={Date.now()} /> } />

          <Route exact path="/" render={(props) => <OrderPage {...props} key={Date.now()} />} />
          
      

          <Route exact path="/menu"  Component={AboutPage} render={(props) => <AboutPage {...props} key={Date.now()} /> } />

          <Route exact path="/search" render={(props) => <SearchPage {...props} key={Date.now()} /> } />

         
          
          <Route exact path="/about_us" Component={About} render={(props) => <RegistrationPage {...props} key={Date.now()} /> } />

          

          <Route exact path="/profile" Component={HomePage} render={(props) => <RegistrationPage {...props} key={Date.now()} /> } />

          
          <Route exact path="/contact_us" Component={ContactPage} render={(props) => <ContactPage {...props} key={Date.now()} /> } />

        </Routes>
        <Footer />
      </Fragment>
    )
  }
}

export default AppRouter

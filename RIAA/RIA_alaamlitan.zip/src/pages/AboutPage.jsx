import React, { Component, Fragment } from 'react'

import List_Of_Items from '../components/home/List_Of_Items';



export class AboutPage extends Component {
  constructor(){
    super();
    window.scroll(0,0)

    }
  render() {
    return (
      <Fragment>
        <List_Of_Items />
  
      </Fragment>
    )
  }
}

export default AboutPage
